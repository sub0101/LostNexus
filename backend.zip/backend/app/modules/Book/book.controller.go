package book

import (
	"fmt"
	"libraryManagement/internal/models"
	"libraryManagement/utility"
	"net/http"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type BookController struct {
	bookService BookService
}

func NewBookController(db *gorm.DB) *BookController {
	bookService := BookService{db: db}
	return &BookController{bookService: bookService}
}

func (bc *BookController) AddBook(c *gin.Context) {
	var book models.BookInventory
	if err := c.ShouldBindBodyWithJSON(&book); err != nil {
		fmt.Println("error", err.Error())
		utility.SendResponse(c, http.StatusBadRequest, false, "Inavalid request", nil, err.Error())
		return
	}

	err := bc.bookService.AddBook(book)
	if err != nil {
		utility.SendResponse(c, 400, false, "Bad Request", nil, err.Error())
	}

}
func (bookController *BookController) GetBook(c *gin.Context) {

}
func (bookController *BookController) GetAllBook(c *gin.Context) {

}
func (bookController *BookController) DeleteBook(c *gin.Context) {

}
func (bookController *BookController) UpdateBook(c *gin.Context) {

}
