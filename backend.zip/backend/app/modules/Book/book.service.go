package book

import (
	"libraryManagement/internal/models"

	"gorm.io/gorm"
)

type BookService struct {
	db *gorm.DB
}

func (bookService *BookService) AddBook(book models.BookInventory) error {

	db := bookService.db

	if err := db.Create(&book).Error; err != nil {
		return err
	}

	return nil
}
func (bookService *BookService) GetBook() {

}
func (bookService *BookService) GeAlltBook() {

}

func (bookService *BookService) UpdateBook() {

}
func (bookService *BookService) DeleteBook() {

}
