package auth

import (
	"fmt"
	"libraryManagement/internal/dto"
	"libraryManagement/internal/models"
	"libraryManagement/utility"

	"gorm.io/gorm"
)

type AuthService struct {
	db *gorm.DB
}

func (service *AuthService) Login(body dto.RequestLoginBody) (uint, string, error) {
	var auth = models.Auth{}
	var user = models.User{}
	db := service.db
	email, password := body.Email, body.Password
	verify := db.Where("email = ?", email).First(&auth)
	if verify.Error != nil {
		return 0, "", fmt.Errorf("Invalid Email ID")
	}

	if utility.VerifyPassword(password, auth.Password) == false {

		return 0, "", fmt.Errorf("Invalid email or  Password")
	}
	db.Where("email = ?", email).First(&user)

	return user.ID, user.Role, nil

}
func (service *AuthService) Signup(user models.User, auth models.Auth) error {

	db := service.db

	err := db.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(&auth).Error; err != nil {
			return err
		}

		if err := tx.Create(&user).Error; err != nil {
			return err
		}
		return nil
	})
	fmt.Println(err)
	return err

}

func (service *AuthService) SignupLibrary(user models.User, auth models.Auth, library models.Library) error {

	db := service.db
	user.Role = "owner"

	err := db.Transaction(func(tx *gorm.DB) error {
		db.Create(&library)
		db.Create(&auth)
		user.LibId = library.ID
		err := db.Create(&user)
		fmt.Println(err.Error)

		return nil
	})
	return err

}
