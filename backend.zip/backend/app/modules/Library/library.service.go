package library

import (
	"gorm.io/gorm"
)

type LibraryService struct {
	db *gorm.DB
}

func (service *LibraryService) GetAllLibrary() {
	db := service.db

	_ = db

}

func (service *LibraryService) AddLibrary() error {
	// db := service.db
	// _ = db
	// err := db.Create(&models.Library{Id: "2121", Name: "dfdfdfd"})
	// if err != nil {
	// 	return err.Error
	// }
	// fmt.Println("created")
	return nil

}
func (service *LibraryService) UpdateLibrary() {
	db := service.db
	_ = db

}
func (service *LibraryService) DeleteLibrary() {
	db := service.db
	_ = db

}
func (service *LibraryService) GetLibrary() {
	db := service.db
	_ = db

}
