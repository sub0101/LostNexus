package library

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type LibraryController struct {
	libraryService LibraryService
}

func NewLibraryController(db *gorm.DB) *LibraryController {

	service := LibraryService{db: db}
	return &LibraryController{libraryService: service}
}

func (lc *LibraryController) GetAllLibrary(c *gin.Context) {

	c.JSON(http.StatusOK, gin.H{"success": true, "message": "All Library Fetched Successfully!"})

}
func (lc *LibraryController) GetLibrary(c *gin.Context) {

	c.JSON(http.StatusOK, gin.H{"success": true, "message": "Library Fetched Successfully!"})
}

func (lc *LibraryController) AddLibrary(c *gin.Context) {
	err := lc.libraryService.AddLibrary()
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"Success": false, "message": err.Error()})
		return
	}
}

func (lc *LibraryController) DeleteLibrary(c *gin.Context) {

}

func (lc *LibraryController) UpdateLibrary(c *gin.Context) {

}
