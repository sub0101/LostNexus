package main

import (
	"libraryManagement/app/routes"
	"libraryManagement/internal/database"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
)

func main() {

	server := gin.Default()
	godotenv.Load(".env")
	err, db := database.InitDB()
	if err != nil {
		server.Use(func(ctx *gin.Context) {
			ctx.AbortWithStatus(501)
		})
	}

	router := server.Group("/api/v1")
	routes.SetupRouter(router, db)

	server.Run(":8000")

}
