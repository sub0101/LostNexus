package models

import (
	"time"

	"gorm.io/gorm"
)

// Users model represents a user in the library system.

type Auth struct {
	gorm.Model
	Email    string `json:"email" binding:"required" gorm:"unique;not null"`
	Password string `json:"password" binding:"require" gorm:"not null"`
}
type User struct {
	gorm.Model
	// Id            string `json:"id" gorm:"primaryKey;size:50;not null"`
	Name          string `json:"name"  binding:"required" gorm:"size:100;not null"`
	Email         string `json:"email"  binding:"required" gorm:"size:100;unique;not null"`
	ContactNumber string `json:"contact"  binding:"required" gorm:"size:15;not null"`
	Role          string `json:"role" gorm:"size:15;not null"`
	LibId         uint   `json:"libraryId"  gorm:"not null"` // Could be foreign key for the library

	Library Library `gorm:"foreignKey:LibId"`
}

// Library model represents a library in the system.
type Library struct {
	gorm.Model
	Name  string          `json:"name" gorm:"unique;size:100;not null"`
	Books []BookInventory `gorm:"foreignKey:LibID;references:ID"` // Explicitly define foreign key
}

type BookInventory struct {
	gorm.Model
	ISBN            string `json:"isbn" gorm:"primaryKey;size:13;not null"`
	LibID           uint   `json:"libraryId" binding:"required" gorm:"not null"`
	Title           string `json:"title" binding:"required" gorm:"size:255;not null"`
	Authors         string `json:"authors" binding:"required" gorm:"size:255"`
	Publisher       string `json:"publisher" binding:"required" gorm:"size:255"`
	Version         string `json:"version" binding:"required" gorm:"size:50"`
	TotalCopies     int    `json:"totalCopies" binding:"required" gorm:"default:0"`
	AvailableCopies int    `json:"availableCopies" binding:"required" gorm:"default:0"`

	Library Library `gorm:"foreignKey:LibID;references:ID"` // Explicit foreign key mapping
}
type RequestEvent struct {
	gorm.Model
	ReqID        uint      `gorm:"primaryKey"`
	BookID       string    ` binding:"required" gorm:"size:13;not null"` // ISBN
	ReaderID     string    `  binding:"required" gorm:"size:50;not null"`
	RequestDate  time.Time `gorm:"not null"`
	ApprovalDate *time.Time
	ApproverID   string `gorm:"size:50"`
	RequestType  string `gorm:"size:50;not null"`
}

type IssueRegistery struct {
	gorm.Model
	IssueID            uint      `gorm:"primaryKey"`
	ISBN               string    `gorm:"size:13;not null"`
	ReaderID           string    `gorm:"size:50;not null"`
	IssueApproverID    string    `gorm:"size:50"`
	IssueStatus        string    `gorm:"size:50;not null"`
	IssueDate          time.Time `gorm:"not null"`
	ExpectedReturnDate time.Time `gorm:"not null"`
	ReturnDate         *time.Time
	ReturnApproverID   string `gorm:"size:50"`
}
