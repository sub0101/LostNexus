package dto

import (
	"libraryManagement/internal/models"

	"gorm.io/gorm"
)

type RequestSignupLibraryBody struct {
	models.User
	LibraryName string `json:"libraryName" binding:"required,min=2" gorm:"not null"`
	Password    string `json:"password" binding:"required,min=8" gorm:"not null"`
}

type RequestSignupUserBody struct {
	gorm.Model
	Name          string `json:"name"  binding:"required" gorm:"size:100;not null"`
	Email         string `json:"email"  binding:"required" gorm:"size:100;unique;not null"`
	ContactNumber string `json:"contact"  binding:"required" gorm:"size:15;not null"`
	Role          string `json:"role" gorm:"size:15;not null"`
	LibId         uint   `json:"libraryId"  binding:"required" gorm:"not null"` // Could be foreign key for the library

	Password string `json:"password" binding:"required,min=8" gorm:"not null"`
}

type RequestLoginBody struct {
	Email    string `json:"email"  binding:"required" gorm:"size:100;unique;not null"`
	Password string `json:"password" binding:"required,min=8" gorm:"not null"`
}

type JwtResponse struct {
	token string
}
